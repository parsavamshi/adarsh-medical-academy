import { Component } from '@angular/core';

@Component({
  selector: 'app-neet',
  templateUrl: './neet.component.html',
  styleUrls: ['./neet.component.scss']
})
export class NeetComponent {

}
