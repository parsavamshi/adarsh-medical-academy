import { Component } from '@angular/core';

@Component({
  selector: 'app-competitves',
  templateUrl: './competitves.component.html',
  styleUrls: ['./competitves.component.scss']
})
export class CompetitvesComponent {

}
