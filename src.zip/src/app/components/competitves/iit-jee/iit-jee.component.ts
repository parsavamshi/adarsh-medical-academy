import { Component } from '@angular/core';

@Component({
  selector: 'app-iit-jee',
  templateUrl: './iit-jee.component.html',
  styleUrls: ['./iit-jee.component.scss']
})
export class IitJeeComponent {

}
