import { Component } from '@angular/core';

@Component({
  selector: 'app-bipc',
  templateUrl: './bipc.component.html',
  styleUrls: ['./bipc.component.scss']
})
export class BipcComponent {

}
