import { Component } from '@angular/core';

@Component({
  selector: 'app-acadamics',
  templateUrl: './acadamics.component.html',
  styleUrls: ['./acadamics.component.scss']
})
export class AcadamicsComponent {

}
