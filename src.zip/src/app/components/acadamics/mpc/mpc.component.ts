import { Component } from '@angular/core';

@Component({
  selector: 'app-mpc',
  templateUrl: './mpc.component.html',
  styleUrls: ['./mpc.component.scss']
})
export class MpcComponent {

}
